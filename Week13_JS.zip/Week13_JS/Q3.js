let valueInINR = 850;
let exchangeRate = 82;
let valueInDollar = valueInINR/exchangeRate;
console.log(valueInINR,"INR is",valueInDollar,"USD");