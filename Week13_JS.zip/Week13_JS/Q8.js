let i = 10;
let j=0;
console.log("Counting from 10 to 0");
while(i>=0)
{
    console.log(i);
    i=i-1;
}
console.log("Counting from 0 to 10");
while(j<=10)
{
    console.log(j);
    j=j+1;
}