let itemNames = ["Milk", "Bread" , "Egg" , "Tea" , "Sugar", "Salt"];
console.log("Following are the items:");
for(let i=0; i<itemNames.length ;i++)
{
    console.log(i+1,":",itemNames[i]);
}