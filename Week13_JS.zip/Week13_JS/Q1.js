let totalValue = 2000;
let discountPercentage = 20;
let discountedValue = totalValue-(totalValue*discountPercentage/100);
console.log("The final price after discount is: Rs.",discountedValue );