let name = "Mithun";
let email = "mithun.s@pw.live";
let age = 21;
if( typeof(name)!= "string"  )
{
    console.log("Name should be a string.");
}
if( typeof(email)!= "string")
{
    console.log("Email should be a string.");
}
if( typeof(age)!= "number")
{
    console.log("Age Should Be A Number.");
}